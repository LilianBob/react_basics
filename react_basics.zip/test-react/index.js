const hiReact = React.createElement("h1", {style: {color: "blue", textAlign: "center"}, className: "header"}, "Hi React")
ReactDOM.render(hiReact, document.getElementById("root"));